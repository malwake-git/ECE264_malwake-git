#include "decode.h"
#include <stdlib.h>
#include <string.h>
int main(int argc, char ** argv)
{
  // argv[1]: name of input file
  // argv[2]: name of output file
  if (argc != 2)
    {
      return EXIT_FAILURE;
    }
  //printf("%d\n",3);
  decode(argv[1]);

  return EXIT_SUCCESS;
}
